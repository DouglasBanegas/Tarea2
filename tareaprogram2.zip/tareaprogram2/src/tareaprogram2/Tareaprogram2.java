package tareaprogram2;

import java.util.Scanner;

public class Tareaprogram2 {

    public static void main(String[] args) {
       
        Scanner entrada = new Scanner (System.in);
        
        
       int resultado = 0, nume1 = 0, nume2 = 0;
       System.out.print("Ingrese una expresion: " +"\n");
        String car = entrada.nextLine();
        
                
     String num1 = "";
     String op = "";
     String num2 = "";
     num1 = car.split(" ")[0];
     op = car.split(" ")[1];
     num2 = car.split(" ")[2];
     
      nume1 = Integer.parseInt(num1);
      nume2 = Integer.parseInt(num2);
        
     if("+".equals(op)){
         resultado = nume1 + nume2;
         
       System.out.print(resultado +"\n"); 
       
     }
        if("-".equals(op)){
         resultado = nume1 - nume2;
         
       System.out.print(resultado +"\n");  
     }
        if("*".equals(op)){
         resultado = nume1 * nume2;
         
       System.out.print(resultado +"\n");  
     }
        if("/".equals(op)){
         resultado = nume1 / nume2;
         
       System.out.print(resultado +"\n");  
     }
         }
         
     }